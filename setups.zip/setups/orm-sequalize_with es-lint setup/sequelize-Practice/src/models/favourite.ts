'use strict';
import { Table, Column, Model, DataType, PrimaryKey, AutoIncrement, Default } from 'sequelize-typescript';
import { favouriteAttributes } from '../interface';


@Table({ tableName: "favourite", timestamps: false })
export default class favourite extends Model<favouriteAttributes> {

  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  id!: number;

  @Column(DataType.INTEGER)
  user_id!: number;

  @Column(DataType.INTEGER)
  product_data_id!: number;

  @Default(false)
  @Column(DataType.INTEGER)
  isdeleted!: number;
}
