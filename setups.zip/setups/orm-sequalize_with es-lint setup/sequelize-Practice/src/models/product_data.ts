'use strict';
import { Table, Column, Model, DataType, PrimaryKey, AutoIncrement } from 'sequelize-typescript';
import { Product_data_Attributes } from '../interface';



@Table({ tableName: "product_data", timestamps: false })
export default class product_data extends Model<Product_data_Attributes> {

    @PrimaryKey
    @AutoIncrement
    @Column(DataType.INTEGER)
    product_data_id!: number;

    @Column(DataType.STRING)
    title!: string;

    @Column(DataType.INTEGER)
    price!: number;

    @Column(DataType.STRING)
    description!: string;

    @Column(DataType.STRING)
    category!: string;

    @Column(DataType.STRING)
    image!: string;

    @Column(DataType.STRING)
    rate!: string;
}