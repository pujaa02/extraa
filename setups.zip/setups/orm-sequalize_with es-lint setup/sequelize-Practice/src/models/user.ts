'use strict';
import { Table, Column, Model, DataType, PrimaryKey, AutoIncrement } from 'sequelize-typescript';
import { UserAttributes } from '../interface';
import { Optional } from 'sequelize';

interface UserCreationAttributes extends Optional<UserAttributes, "user_id"> { }

@Table({ tableName: "Users", timestamps: true })
export default class User extends Model<UserAttributes, UserCreationAttributes> {
  @PrimaryKey
  @AutoIncrement
  @Column(DataType.INTEGER)
  user_id!: number;

  @Column(DataType.STRING)
  fname!: string;

  @Column(DataType.STRING)
  lname!: string;

  @Column(DataType.STRING)
  email!: string;

  @Column(DataType.BIGINT)
  phone!: number;

  @Column(DataType.STRING)
  gender!: string;

  @Column(DataType.DATEONLY)
  bd!: Date;

  @Column({ type: DataType.STRING, allowNull: true })
  password!: string | null;

  @Column({ type: DataType.STRING, allowNull: true })
  access_key!: string | null;

  @Column({ type: DataType.INTEGER, allowNull: true, defaultValue: 0 })
  isdeleted!: number | null;
}
