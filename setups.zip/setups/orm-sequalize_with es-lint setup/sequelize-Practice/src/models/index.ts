import dotenv from "dotenv";
dotenv.config();
import { Sequelize } from "sequelize-typescript";
import User from "./user";
import product_data from "./product_data";
import watchlist from "./watchlist";
import favourite from "./favourite";

const initSequalize = () => {
  const sequelize = new Sequelize({
    database: process.env.DATABASE,
    username: process.env.DBUSER,
    password: process.env.DBPASSWORD,
    host: process.env.HOST,
    dialect: "mysql",
    port: 3306,
    models: [User, product_data, watchlist, favourite],
  });

  sequelize
    .authenticate()
    .then(() => console.log(`Successfully connected to database!`))
    .catch((err) => console.log(`Something went wrong ${err.message}`));

  return sequelize;
};

const db = {
  connect: initSequalize(),
};

export default db;