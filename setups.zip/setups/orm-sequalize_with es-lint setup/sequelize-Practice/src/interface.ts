export interface UserAttributes {
    user_id: number;
    fname: string;
    lname: string;
    email: string;
    phone: number;
    gender: string;
    bd: Date;
    password?: string;
    access_key?: string;
    isdeleted?: number;
    createdAt?: Date;
    updatedAt?: Date;
  }
  export  interface watchlistAttributes {
    id: number;
    user_id: number;
    product_data_id: number;
    count: number;
    isDeleted: number;
  }
  export  interface Product_data_Attributes {
    product_data_id: number;
    title: string;
    price: number;
    description: string;
    category: string;
    image: string;
    rate: number;
}
export interface favouriteAttributes {
  id: number;
  user_id: number;
  product_data_id: number;
  isDeleted: number;
}
