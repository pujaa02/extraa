import express, { Application ,Request, Response} from "express";
const app: Application = express();
import dotenv from "dotenv";
dotenv.config();
const port = process.env.PORT;
app.get("/", (req: Request, res: Response) => {
    res.send("hello");
});

try {
    app.listen(port, () => {
        console.log(`Server is running in port: ${port} `);
    });
} catch (error) {
    console.log(`Error: ${error}`);
}
